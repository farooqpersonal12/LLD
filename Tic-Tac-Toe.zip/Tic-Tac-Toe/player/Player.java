package player;

import symbol.symbol;

public class Player {
    private int id;
    private String name;
    private symbol symbol;

    public Player(int id, String name, symbol symbol) {
        this.id = id;
        this.name = name;
        this.symbol = symbol;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public symbol getSymbol() {
        return symbol;
    }

    public void setSymbol(symbol symbol) {
        this.symbol = symbol;
    }

}
