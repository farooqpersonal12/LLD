package board;

import symbol.symbol;

public class Board {
    public static final int SIZE = 3;

    private symbol[][] grid;
    private symbol emptyCell;

    public Board() {
        emptyCell = new symbol();
        emptyCell.setMark('_');
        grid = new symbol[SIZE][SIZE];

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                grid[i][j] = emptyCell;
            }
        }
    }

    public boolean isCellEmpty(int row, int col) {
        return isInBounds(row, col) && grid[row][col] == emptyCell;
    }

    public void placeMark(int row, int col, symbol mark) {
        if (isCellEmpty(row, col)) {
            grid[row][col] = mark;
        }
    }

    public symbol getCell(int row, int col) {
        return grid[row][col];
    }

    public void display() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                System.out.print(grid[i][j].getMark() + " ");
            }
            System.out.println();
        }
    }

    private boolean isInBounds(int row, int col) {
        return row >= 0 && row < SIZE && col >= 0 && col < SIZE;
    }
}
